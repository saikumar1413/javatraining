package com.infinite.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author saikumarpu
 *
 */
@Entity
@Table(name = "Product") //table name
public class Product {
	@Id
	@Column(name = "id")  //setting primary key
	@GeneratedValue(strategy = GenerationType.AUTO) // using autogenerative
	private int id;

	@Column(name = "ProductName")
	private String ProductName; //productname column

	@Column(name = "Price")
	private int Price; //price column

	@Column(name = "Quantity")
	private int Quantity;  //quantity column

	@Column(name = "SubTotal")
	private int SubTotal; //subtotal column

	public Product() {  //empty constructor
		// super();
	}
	//generating getters and setters
	public int getId() {   
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public int getSubTotal() {
		return SubTotal;
	}

	public void setSubTotal(int subTotal) {
		SubTotal = subTotal;
	}

}
