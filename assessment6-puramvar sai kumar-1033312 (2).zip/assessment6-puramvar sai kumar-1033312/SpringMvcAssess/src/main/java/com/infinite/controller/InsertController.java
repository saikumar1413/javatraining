package com.infinite.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.impl.ProductImpl;
import com.infinite.pojo.Product;

/**
 * @author saikumarpu
 *
 */
@Controller
public class InsertController { //child controller
	private ApplicationContext con;  //initializing applicationcontext
	@RequestMapping(value="/insert",method=RequestMethod.POST)  //request mapper to find child controller
	public String insert(@ModelAttribute("bean") Product e,Model m){  
		con=new ClassPathXmlApplicationContext("ApplicationContext.xml");  //creating object for applicationcontext
		ProductImpl obj=con.getBean("dao",ProductImpl.class);  //getting productimpl using bean id
		obj.saveData(e); //insertdata
		 
		String ProductName=e.getProductName();
		int Price=e.getPrice();
		int Quantity=e.getQuantity();
		int SubTotal=e.getSubTotal();
		//Session sessionobj = sessionFactory;
		m.addAttribute("msg",ProductName); 
		System.out.println("i");
		return "inserted";	
	}

}
