package com.infinite.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.infinite.helper.Helper;
import com.infinite.pojo.Product;

/**
 * @author saikumarpu
 *
 */
public class ProductImpl {
	static Session sessionObj; // creating session object
	static SessionFactory sessionFactoryObj; // creating sessionfactory object
	private Configuration con; // creating configuration object
	private Transaction t; // //creating transaction object

	// private Session sessionObj;
	public void saveData(Product e) { // creating saveData method to insert into
										// db
		con = new Configuration().configure("hibernate.cfg.xml");
		sessionFactoryObj = con.buildSessionFactory();
		sessionObj = sessionFactoryObj.openSession();
		t = sessionObj.beginTransaction();
		sessionObj.save(e);
		t.commit();

	}

	public void createRecord(Product e) {
		// TODO Auto-generated method stub
		// Getting Session Object From SessionFactory

		try {
			sessionObj = Helper.buildSessionFactory().openSession(); // opening
																		// session
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction(); // beginning transaction
			Product st = (Product) sessionObj.get(Product.class, e.getId()); // creating
																				// obj
																				// for
																				// product
																				// class
			st.setProductName(st.getProductName()); // getting and setting
													// productname
			st.setPrice(st.getPrice()); // getting and setting price
			st.setQuantity(st.getQuantity()); // getting and setting quantity
			st.setSubTotal(st.getSubTotal()); // getting and setting subtotal
			/*
			 * sessionObj.update(StudentName); sessionObj.update(RollNumber);
			 * sessionObj.update(Course);
			 */
			sessionObj.update(st); // updating
			sessionObj.save(st); // saving to db
			sessionObj.getTransaction().commit(); // commiting
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				sessionObj.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}

		}

	}

	// private Session sessionObj;
	public void deleteData(Product e) { // creating deleteData method to
										// deleting from db
		con = new Configuration().configure("hibernate.cfg.xml");
		sessionFactoryObj = con.buildSessionFactory();
		sessionObj = sessionFactoryObj.openSession();
		t = sessionObj.beginTransaction();
		sessionObj.delete(e);
		t.commit();

	}

	public void Delete(Product e) {
		// TODO Auto-generated method stub
		// Getting Session Object From SessionFactory

		try {
			sessionObj = Helper.buildSessionFactory().openSession(); // opening
																		// session
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction(); // begging transaction
			Product st = (Product) sessionObj.get(Product.class, e.getProductName()); // creating
																						// obj
																						// for
																						// product
																						// class
			sessionObj.delete(st); // deleting
			sessionObj.update(st); // after deleting updating data
			sessionObj.save(st); // saving data
			sessionObj.getTransaction().commit(); // commiting to db
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				sessionObj.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}

		}
	}

	public void updateData(Product e) {
		con = new Configuration().configure("hibernate.cfg.xml");
		sessionFactoryObj = con.buildSessionFactory();
		sessionObj = sessionFactoryObj.openSession();
		t = sessionObj.beginTransaction();
		sessionObj.update(e);
		t.commit();

	}

	public void update(Product e) {
		// TODO Auto-generated method stub
		// Getting Session Object From SessionFactory

		try {
			sessionObj = Helper.buildSessionFactory().openSession(); // opening
																		// session
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();
			Product st = (Product) sessionObj.get(Product.class, e.getId());// creating
																			// obj
																			// for
																			// product
																			// class
			st.setProductName(st.getProductName()); // getting and setting
													// productname
			st.setPrice(st.getPrice()); // getting and setting price
			st.setQuantity(st.getQuantity()); // getting and setting quantity
			st.setSubTotal(st.getSubTotal()); // getting and setting subtotal

			sessionObj.update(st);
			sessionObj.save(st);
			sessionObj.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				sessionObj.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}

		}

	}
}