import './App.css';
import Population from './component/Population';

function App() {
  return (
    <div className="App">
     <Population/>
    </div>
  );
}

export default App;
