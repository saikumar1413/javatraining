/*package com.h2.H2DataBase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2DataBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/