package com.infinite.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.model.Employee;
import com.infinite.repository.EmployeeRepository;

@Service  //initializing service to write business logic
public class EmployeeService {
	//autowiring repository layer to service to access methods
	@Autowired
	EmployeeRepository empRepository;

	// to insert into db 
	public Employee createEmployee(Employee emp) {
		return empRepository.save(emp);
	}

	// to list all employess
	public List<Employee> getEmployees() {
		return empRepository.findAll();
	}
}