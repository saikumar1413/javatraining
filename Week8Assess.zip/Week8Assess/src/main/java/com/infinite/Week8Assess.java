package com.infinite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week8Assess {
	public static void main(String[] args) {
		SpringApplication.run(Week8Assess.class, args);
	}
}