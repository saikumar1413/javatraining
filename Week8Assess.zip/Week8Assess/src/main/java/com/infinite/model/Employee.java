package com.infinite.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity  //to create table
@Table(name="employee") //specifying table name
public class Employee {
	@Id  //making primary key as empid
	@GeneratedValue(strategy=GenerationType.AUTO) 
	//generating table automatically
	//columns and name
	@Column(name="EmpId")
	private int empid;
	@Column(name="FirstName")
	private String fname;
	@Column(name="LastName")
	private String lname;
	@Column(name="Deapartment")
	private String Deapartment;
	
	//generating getters and setters
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getDeapartment() {
		return Deapartment;
	}
	public void setDeapartment(String deapartment) {
		Deapartment = deapartment;
	}
}