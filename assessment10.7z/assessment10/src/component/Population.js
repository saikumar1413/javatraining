import React from "react";
import axios from "axios";
export default class Population extends React.Component {
    state = {
        persons: []
    }



    componentDidMount() {
        axios.get('https://datausa.io/api/data?drilldowns=Nation&measures=Population')
            .then(res => {
                const persons = res.data;
                console.log(this.state.persons)
                this.setState({ persons: persons.data });
            })
    }

    render() {
        return (
            <div>
                <table border="1">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Year</th>
                            <th>Population</th>
                        </tr>

                    </thead>
                    <tbody>
                        {
                            this.state.persons
                                .map(person =>
                                    <tr key={person.Nations}>
                                        <td>{person["ID Nation"]}</td>
                                        <td>{person.Year}</td>
                                        <td>{person.Population}</td>
                                    </tr>

                                )
                        }

                    </tbody>
                </table>
            </div>

        )
    }
}