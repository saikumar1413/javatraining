package com.infinite.log4jexample;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Example1 {
	
	private static final Logger Logger = org.apache.log4j.Logger.getLogger(Example1.class);
	
	{
		Logger.info("unnamed block");
	}
	
	public static void display()
	{
		Logger.info("hi from display");
	}
	
	public static void displaynonstatic()
	{
		try {
			int a=1/0;
			
		}
		catch(Exception e)
		{
			Logger.error("display non static");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
		Logger.info("hi hello world");
		Logger.warn("pls dont use it");
		Logger.error("Heap Error Occured");
		Logger.fatal("Error Occured");
		display();
		displaynonstatic();
		
	}

}
