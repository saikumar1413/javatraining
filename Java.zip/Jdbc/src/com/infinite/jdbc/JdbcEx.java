package com.infinite.jdbc;

import java.sql.Connection;

public class JdbcEx {
	
	public static void main(String args[]){
		Connection on= null;
		
	}

}
