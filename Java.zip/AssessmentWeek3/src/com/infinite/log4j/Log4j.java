package com.infinite.log4j;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

//import com.infinite.log4j;

public class Log4j {
	private static final Logger logger = org.apache.log4j.Logger.getLogger(Log4j.class);
	public static void display()
	{
		logger.info("Infinite Solutions");
	}
	public static void backend()
	{
		logger.info("Java Backend");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
		display();
		backend();

	}

}
