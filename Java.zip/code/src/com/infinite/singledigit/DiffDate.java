package com.infinite.singledigit;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class DiffDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the start date(yyyy-mm-dd hh:mm:ss):");
		String starDateString=sc.nextLine();
		System.out.println("Enter the end Date(yyyy-mm-dd hh:mm:ss):");
		String endDateString=sc.nextLine();
		SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-mm-dd hh:mm:ss):");
		try {
			Date startDate=dateFormat.parse(starDateString);
			Date endDate=dateFormat.parse(endDateString);
			long differenceinmillisec=endDate.getTime()-startDate.getTime();
			long diffinmin=TimeUnit.MILLISECONDS.toMinutes(differenceinmillisec);
			long diffindays=TimeUnit.MILLISECONDS.toDays(differenceinmillisec);
			System.out.println("Difference in days: "+diffindays+" days");
			System.out.println("Difference in minutes: "+diffinmin+" minutes");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally {
			System.out.println("completed");
		}
	}

}
