package com.infinite.singledigit;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

//import com.infinite.jdbc.JdbcConnectionExample;
public class Singledigit {
	public static void main(String... args) {
		final Logger logger = Logger.getLogger(Singledigit.class);
		PropertyConfigurator.configure("log4j.properties");
		int a = 0;
		int b = 10;
		int c;
		Scanner sc = new Scanner(System.in);
		c = sc.nextInt();
		if (c >= a && c < b) {
			logger.info("single digit number");
		} else {
			logger.info("not a single digit");
		}
	}

}
