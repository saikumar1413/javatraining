package com.infinite.singledigit;
import com.infinite.interfacesimpl.*;
public class InterfaceTest {
	public static void main(String [] args)
	{
		Ecommerceimpl obj = new Ecommerceimpl();
		obj.applemobile();
		obj.jiomobile();
		
	}

}
