package com.infinite.singledigit;
import com.infinite.product.*;
public class Publictest {
	public static void main(String [] args) {
		Pubtest d = new Pubtest();
		System.out.println(d.display());
	}

}
