package com.infinite.oops;

abstract class Requirements
{
	public abstract void display();
}

public class AbstractExample {
	public static void main(String [] args)
	{
		
	}

}
