package com.infinite.oops;

public class ClassExample {

	boolean state;

	public void dispaly(boolean stat) {
		if(state=stat)
		System.out.println("Light on");
		else
			System.out.println("Light off");

	}

	public static void main(String[] args) {
		
		ClassExample op = new ClassExample();
		op.dispaly(false);
		
	}

}
