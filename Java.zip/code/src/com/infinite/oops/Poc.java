package com.infinite.oops;

import java.util.Scanner;
import java.util.ArrayList;

class Account
{
	public double balance=0;
	@SuppressWarnings("unchecked")
	public static void getDetails()
	{
		//System.out.println("Enter account number");
		ArrayList accountid = new ArrayList();

		accountid.add("1234567ABCD");
		accountid.add("1234568ABCD");
		accountid.add("1234569ABCD");
		accountid.add("1234570ABCD");
		accountid.add("1234571ABCD");
		accountid.add("1234572ABCD");
		accountid.add("1234573ABCD");
		accountid.add("1234574ABCD");
		accountid.add("1234575ABCD");
		accountid.add("1234576ABCD");		
		
		@SuppressWarnings("rawtypes")
		ArrayList accountname = new ArrayList();
		accountname.add("sai1");
		accountname.add("sai2");
		accountname.add("sai3");
		accountname.add("sai4");
		accountname.add("sai5");
		accountname.add("sai6");
		accountname.add("sai7");
		accountname.add("sai8");
		accountname.add("sai9");
		accountname.add("sai0");
		
		
		@SuppressWarnings("rawtypes")
		ArrayList accountdetails = new ArrayList();
		accountdetails.add(accountid);
		accountdetails.add(accountname);
		accountdetails.subList(0, 0);
		System.out.println(accountdetails);
	
	}
	
	public void showDetails()
	{
	
	}
}
	

class Loan extends Account
{
	public void getLoan()
	{
		
	}
	
	public void showLoanDetails()
	{
		
	}
}

class Transaction extends Account
{
	public void depositAmount(double amount)
	{
		balance += amount;
	}
	
	public void withdrawAmount(double amount)
	{
		if(balance>=amount)
		{
			balance-=amount;
		}
		else
		{
			System.out.println("insufficient balance");
		}
	}
	
	public void payLoan()
	{
		
	}
	
	public void showAccountDetails()
	{
		
	}
}
public class Poc {

	public static void main(String [] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Account obj = new Account();
		obj.getDetails();
		String user = sc.next();
		user.matches(user);
		System.out.println(user.equals(user));
		/*ArrayList accountid = new ArrayList();

		accountid.add("1234567ABCD");
		accountid.add("1234568ABCD");
		accountid.add("1234569ABCD");
		accountid.add("1234570ABCD");
		accountid.add("1234571ABCD");
		accountid.add("1234572ABCD");
		accountid.add("1234573ABCD");
		accountid.add("1234574ABCD");
		accountid.add("1234575ABCD");
		accountid.add("1234576ABCD");		
		
		ArrayList accountname = new ArrayList();
		accountname.add("sai1");
		accountname.add("sai2");
		accountname.add("sai3");
		accountname.add("sai4");
		accountname.add("sai5");
		accountname.add("sai6");
		accountname.add("sai7");
		accountname.add("sai8");
		accountname.add("sai9");
		accountname.add("sai0");
		
		
		ArrayList accountdetails = new ArrayList();
		accountdetails.add(accountid);
		accountdetails.add(accountname);*/
	}
}


