package com.infinite.oops;

/*class A
{
	public void display()
	{
		System.out.println("a");
	}
}

class B extends A
{
	public void display()
	{
		super.display();
		System.out.println("B");
	}
}*/

class A
{
	public void display()
	{
		
		System.out.println("parent class");
	}
}

class B extends A
{
	public void display()
	{
		super.display();
		System.out.println("child class");
	}
}

class C extends B
{
	public void display()
	{
		super.display();
		System.out.println("third clas");
	}
}

public class OverridingExample1 {
	
	public static void main(String [] args)
	{
		C obj = new C();
		obj.display();
		
		
	}

}
