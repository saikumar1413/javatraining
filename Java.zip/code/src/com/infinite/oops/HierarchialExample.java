package com.infinite.oops;

class A2
{
	public void display4()
	{
		System.out.println("display4 method invocated");
	}
}

class B2 extends A2
{
	public void display5()
	{
		System.out.println("display5 method invocated");
	}
}

class C2 extends A2
{
	public void display6()
	{
		super.display4();
		System.out.println("display6 method invocated");
	}
}
public class HierarchialExample {
	
	public static void main(String [] args)
	{
		C2 ob = new C2();
		ob.display6();
	}

}
