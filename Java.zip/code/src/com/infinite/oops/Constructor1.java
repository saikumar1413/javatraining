package com.infinite.oops;


class stat1 {
	int a;
	String name1;
	stat1() { 
		a = 90;
		return;
	}
	stat1(String name)
	{
		this.name1 = name;
	}
}

public class Constructor1 {
	
	public static void main(String [] args)
	{
		stat1 ref = new stat1("sai");
		stat1 ref1= new stat1();
		System.out.println(ref1.a);
		System.out.println(ref.name1);
	}

	}


