package com.infinite.oops;

class A1
{
	A1()
	{
		int a = 5; 
		int b = 6;
		int c =a+b;
		System.out.println(c);		
	}
	public static void display1()
	{
		System.out.println("display1 method invocated");
		
	}
}

class B1 extends A1
{
	B1()
	{
		int d=5;
		super.display1();
		System.out.println(d);
		//super.display1();
	}
	public static void display2()
	{
		System.out.println("display2 method invocated");
	}
}

class C1 extends B1
{
	C1()
	{
		int e = 21;
		System.out.println(e);
		super.display2();
	}
	public static void display3()
	{
		System.out.println("display3 method invocated");
	}
}
public class MultilevelExample1 {
	
	public static void main(String [] args)
	{
		C1 obj = new C1();
		
		obj.display3();
	
		
	}

}
