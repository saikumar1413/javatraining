package com.infinite.product;

public class CmdExample {
	public static void main(String [] args)
	{
		System.out.println(args[0]);
		
	}

}
