package com.infinite.product;

public class leapyear {
	public static void main(String...args)
	{
		int a = 2024;
		if(a % 4 == 0)
		{
			System.out.println("a is a leap year");
		}
		else
		{
			
			
			System.out.println("not a leap year");
		}
	}

}
