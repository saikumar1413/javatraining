package com.infinite.product;

public class WhileExample2 {
	
	public static void main(String [] args)
	{
		/*int i = 1;
		while(i<=4){
		System.out.print(i+"a");
		i++;
		}*/
		int i = 2345;
		while(i<=5678)
		{
			if(i%2==0){
			System.out.println(i+" is a even number");
		}
		else
		{
			System.out.println(i+" is a odd number");
		}
		i++;
	}
		/*int i = 0;
		while(i <= 80)
		{
			i=i+10;
		if(i == 60)
			{
				continue;
			}
		else
		{
			System.out.println(i);
		}
		}*/
	}
}

