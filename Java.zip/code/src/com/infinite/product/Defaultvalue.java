package com.infinite.product;

public class Defaultvalue {

	int a;
	char b;
	byte y;
	boolean n;
	long ll;
	String name;
	double db;
	float fl;
	int y1= 89;
	public static void main(String [] args)
	{
		Defaultvalue obj = new Defaultvalue();
		System.out.println(obj.a);
		System.out.println(obj.b);
		System.out.println(obj.y);
		System.out.println(obj.n);
		System.out.println(obj.ll);
		System.out.println(obj.name);
		System.out.println(obj.db);
		System.out.println(obj.fl);
		
	}
}
