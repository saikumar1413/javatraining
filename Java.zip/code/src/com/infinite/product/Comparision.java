package com.infinite.product;

public class Comparision {
	public static void main(String...args)
	{
		int a = 90;
		int b = 80;
		int c = 170;
		if(a>b&&a>c)
		{
		System.out.println("a is highest");
		}
		else if(b>a&&b>c)
		{
		System.out.println("b is highest");	
		}
		else if(c>a&&c>b)
		{
			System.out.println("c is highest");
		}
		if(a<b&&a<c)
		{
			System.out.println("a is lowest");
		}
		else if(b<a&&b<c)
		{
			System.out.println("b is lowest");
		}
		else if(c<a&&c<b)
		{
			System.out.println("c is lowest");
		}
		
	}

}
