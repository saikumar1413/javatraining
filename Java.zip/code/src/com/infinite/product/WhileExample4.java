package com.infinite.product;

public class WhileExample4 {
	public static void main(String [] args)
	{
		int s = 97;
		while(s<=107)
		{
			System.out.print((char)s+" ");
		s++;
		}
	}

}


