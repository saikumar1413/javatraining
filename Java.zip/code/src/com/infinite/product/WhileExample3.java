//@saikumar
package com.infinite.product;

public class WhileExample3 { // to display 1a 2b
	
	public static void main(String [] args)
	{
		int i = 1;
		int j = 97; //lower case ASCII value
		while(i<=26) // while condition to print series of 1a 2b 3c ...
		{
			System.out.print(i+ ""+(char)j+" "); // converting int to char and printing
			i++;
			j++;
			
			
		}
	}
	
	
	}


