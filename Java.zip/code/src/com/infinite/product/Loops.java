package com.infinite.product;

public class Loops {
	public static void main(String [] args)
	{
		/*int i=15;
		while(i>=10)
		{
			while(i<=20)
			{
				System.out.print(i);
				i++;
			}
		}*/
		int j = 20;
		while(j >= 10)
			{
			do {
			System.out.print(j);
			j++;
			}while(j<=25);
		    }
	}

}
