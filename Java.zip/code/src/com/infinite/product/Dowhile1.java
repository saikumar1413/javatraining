//@saikumar
package com.infinite.product;

public class Dowhile1 { // using do while to print 50 to 1
	public static void main(String [] args)
	{
		int i = 50;
		do {
			System.out.print(i+" "); //displaying 50 to 1 
			i--;
		}while(i>0); // checking condition
	}

}
