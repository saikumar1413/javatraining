package com.infinite.product;

public class String3 {
	public static void main(String [] args)
	{
		String s = "i am bad programmer";
		for(int i=1;i<=5;i++)
		{
			System.out.println(s+s+s+s+s);
		}
	}

}
