package com.infinite.product;

public class StringExample1 {
	public static void main(String [] args)
	{
		String y[] = {"monday","tuesday","wednesday","thursday"};
		
		/*String e = y[2].toUpperCase();
		char t[] = e.toCharArray();
		int p = t.length-1;
		while(p>=0)
		{
			System.out.print(t[p]+" ");
			p--;
		}
		String f = y[3].toUpperCase();
		char g[] = f.toCharArray();
		int q = g.length-1;
		while(q>=0)
		{
			//System.out.print(" ");
			System.out.print(g[q]+" ");
			q--;
		}*/
		int i = 0;
		while(i<4)
		{
			String g = y[i].toUpperCase();
			char s[] = g.toCharArray();
			int r = s.length-1;
			while(r>=0)
			{
				System.out.print(s[r]+"");
				r--;
			}
			System.out.println("");
			i++;
		}
	}

}
        