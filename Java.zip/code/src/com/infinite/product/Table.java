//@saikumar
package com.infinite.product;

public class Table {  // to display multiplication table
	public static void main(String [] args)
	{
		int a = 24; // to print 24 table a is taken as 24
		int i=1;
		int j;
		while(i<=10) // condition to print upto 12*10 
		{
			j=a*i;
			System.out.println(a+"*"+i+"="+j); //displaying 24th table
		i++;
		}
	}

}
