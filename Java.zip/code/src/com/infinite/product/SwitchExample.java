package com.infinite.product;

public class SwitchExample {
	public static void main(String [] args)
	{
		int a = 10;
		switch(a)
		{
		case 10:
			System.out.println("10");
			break;
		case 12:
			System.out.println("12");
			break;
		case 101:
			System.out.println("101");
			break;
		default:
			System.out.println("default");
			
		}
		
	}

}
