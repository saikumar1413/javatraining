//@sai kumar

package com.infinite.product;

public class String2 {
	
	public static void main(String [] args)
	{
		String a = "INFINITE";
		String b = "infinite";
		System.out.println(a.length());
		String u = a.trim();
		System.out.println(u.length());
		System.out.println(u.substring(0, 3));
		System.out.println(u.charAt(4));
		System.out.println(a.equalsIgnoreCase(b));
		System.out.println(a.indexOf('I'));
		System.out.println(a.isEmpty());
		System.out.println(a.lastIndexOf('N'));
		System.out.println(b.equalsIgnoreCase(a));
		System.out.println(a.concat(b));
		System.out.println(a.endsWith(b));
		System.out.println(b.hashCode());
		System.out.println(b.replaceAll(b, a));
		System.out.println(b.compareTo(a));
		
		String c = "Returns the index within this string of the first occurrence";
		char d[] = c.toCharArray();
		System.out.println(d);
		
	}

}
