package com.infinite.product;

import java.util.Scanner;

public class Function {
	
	public static void swapping(int a, int b)
	{
		
		int temp=0;
		temp=a;
		a=b;
		b=temp;
				
		System.out.println(a);
		System.out.println(b);
	}
	
	public static void displaytable(int i)
	{
		int j = 1;
		while(j<=10)
		{
			int k=i*j;
			System.out.println(i+"*"+j+"="+k);
			j++;
		}
	}
	
	public void displayalphabets()
	{
		int sc = 65;
		while(sc<=90)
		{
			System.out.print((char)sc+" ");
			sc++;
		}
		
	}
	public static void main(String [] args)
	{
		Function obj = new Function();
		Scanner s = new Scanner(System.in);
		int a = s.nextInt();
		int b = s.nextInt();
		int i = s.nextInt();
		swapping(a,b);
		displaytable(i);
		obj.displayalphabets();
		return;
		
	}

}
