package com.infinite.product;
import java.util.Scanner;
public class StaticExample {
	
	static int a= 90;
	
	public int add(int a, int b)
	{
		return a+b;
	
	}
	public static void main(String [] args)
	{
		StaticExample obj = new StaticExample();
		Scanner s = new Scanner(System.in);
		//System.out.println("input for a = ");
		//int a = s.nextInt();
		System.out.println("input for b = ");
		int b = s.nextInt();
		System.out.println(obj.add(a,b));
	}

}
