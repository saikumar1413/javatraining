package com.infinite.product;

public class ExceptionExample {

}
