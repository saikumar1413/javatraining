package com.infinite.product;

import java.util.Scanner;

public class ArrayExample1 {
	
	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);
		int [] a = new int[5]; // syntax1
		int b[] = new int [5];// syntax2
		int [] c = {11,22,33,44,55,66};// syntax3
		
		int i =0;
		while(i<c.length)
		{
			System.out.println(c[i]);
			i++;
		}
		
		for(i=0;i<5;i++)
		{
			b[i]=sc.nextInt();
		}
		i = 0;
		while(i<3)
		{
			System.out.println(b[i]);
			i++;
		}
		String y[] = {"monday","tuesday","wednesday"};
		char y1[] = {'a','b','c','d'};
		System.out.println(y1);
	}

}
