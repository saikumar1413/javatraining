package com.infinite.product;

class APP {
	//public int a = 21;
	private int a = 22;
	public int mat(){
	int y = a;
	return y;
	}
}
public class Pubtest {
	
	public int display()
	{
		APP u = new APP();
				//return u.a;
		return u.mat();
	}
	
	public static void main(String [] args) {
		APP s = new APP();
		//System.out.println(s);
		
	}
	

}
