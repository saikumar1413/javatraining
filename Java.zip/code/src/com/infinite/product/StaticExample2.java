package com.infinite.product;


class stat
{
	int a = 90;
	int a1= 900;
	int a2 = 95;
	
	//named block
	public static void display()
	{
		System.out.println("display from stat class");
	}
	//unamed block
	
	{
		System.out.println("unnamed block");
	}
	
	//static block
	static
	{
		System.out.println("static block");
	}
}

public class StaticExample2 {
	
	public static void main(String [] args)
	{
		stat ref = new stat(); 
		ref.display();//object memory is allocated
		// stat ref1 = null; reference here memory is not allocated 
		stat.display();
		System.out.println(new stat().a1);
		System.out.println(ref.a);
		
	}

}
