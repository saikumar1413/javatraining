package com.infinite.product;

import java.util.Scanner;

public class sai {
	public static void main(String [] args)
	{
		Scanner s = new Scanner(System.in);
		int a = s.nextInt();
		if(a>650)
			System.out.println("good credit score");
		else
			System.out.println("Bad score");
	}

}
