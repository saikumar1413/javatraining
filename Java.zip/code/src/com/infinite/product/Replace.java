package com.infinite.product;

public class Replace {
	
	public static void main(String[] args)
	{
		String str = "Returns the index within this string of the first occurrence";
	
		//System.out.println(str.replace('i', 'p'));
		int count=0;
		char t[] = str.toCharArray();
		//int n=t.length-1;
		for(int i=0;i<t.length-1;i++)
		{
		if(t[i]=='i')
		{
			count++;
		}
		}
		System.out.println(count);
	}

}
