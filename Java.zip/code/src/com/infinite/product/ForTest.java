package com.infinite.product;

public class ForTest {
	public static void main(String [] args)
	{
		int i[] = {11,22,33,44};
		for(int a = 0;a<i.length;a++){
			System.out.println(i[a]);
		}
	}

}
