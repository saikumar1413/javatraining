package com.infinite.product;

public class MethodExample {

	public static int display(int a, int b) {
		return a + b;
	}

	public int display1(int a, int b) {
		return a + b;
	}

	public static void main(String[] args) {

		MethodExample obj = new MethodExample();

		System.out.println(obj.display1(3, 3));
	}

}
