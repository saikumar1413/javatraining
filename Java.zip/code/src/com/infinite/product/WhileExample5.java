package com.infinite.product;

public class WhileExample5 {
	public static void main(String [] args)
	{
		int i = 1;
		while(i<=4)
		{
			System.out.print(i+"");
			i++;
		}
		int j = 4;
		while(j>0)
		{
			System.out.print(j+"");
		j--;
		}
	}
}
