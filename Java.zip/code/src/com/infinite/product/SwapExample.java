package com.infinite.product;

//sai kumar
//swapping of two numbers without 3rd variable
public class SwapExample {
	public static void main(String...args)
	{
		int a = 90;
		int b = 190;
		System.out.println("a= "+a);
		System.out.println("b= "+b);
		b = (a+b)-(a=b);
		a = (a+b)-(b=a);
		System.out.println("a= "+b);
		System.out.println("b= "+a);
	}

}
