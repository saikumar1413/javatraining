package com.infinite.product;

public class WhileExample {
	
	public static void main(String [] args)
	{
		int j = 10;
		while(j<=15)
		{
			System.out.print(j+" ");
			j++;
		}
			
	
	}

}
