package com.infinite.product;

import java.util.Scanner;

public class ArrayExample2 {
	int i;
	int a[] = new int[5] ;
	
	public void display()
	{
		Scanner sc = new Scanner(System.in);
		for(i=0;i<5;i++)
		{
		a[i] = sc.nextInt();
		}
		for(i=0;i<5;i++)
		{
		System.out.print(a[i]+"\t");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayExample2 obj = new ArrayExample2();
		
		obj.display();

	}

}
