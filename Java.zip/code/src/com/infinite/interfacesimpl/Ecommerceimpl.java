package com.infinite.interfacesimpl;
import com.infinite.interfaces.*;
public class Ecommerceimpl implements Ecommerce {

	@Override
	public void samsungmobile() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lgmobile() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void jiomobile() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void applemobile() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void vivomobile() {
		// TODO Auto-generated method stub
		
	}

}
