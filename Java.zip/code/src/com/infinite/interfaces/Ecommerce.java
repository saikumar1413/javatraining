package com.infinite.interfaces;

/**
 * @author saikumarpu
 * The interface is entry point for the ecommerce app
 */
public interface Ecommerce {
	
	
		public void samsungmobile();
		public void lgmobile();
		public void jiomobile();
		public void applemobile();
		public void vivomobile();
	}



