package com.infinite.collections;

import java.util.Iterator;
import java.util.HashSet;
import java.util.TreeSet;

public class HashSetExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet ls = new HashSet();
		ls.add(25);
		ls.add("sai");
		ls.add(33.45f);
		ls.add('S');
		ls.add("sai");
		//ls.remove("sai"); 
		ls.size();
		System.out.println(ls);
		
		/*for (int a = 89; a <= 100; a++)
			ls.add(a);
		System.out.println(ls);
		System.out.println("size" + " " + ls.size());
		System.out.println(ls.get(3));
		System.out.println(ls.isEmpty());
		System.out.println(ls.remove(1));
		System.out.println(ls.toArray());
		Iterator it = ls.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		for (Object p : ls) {
			System.out.println(p);
		}

	}*/
		
}


}
