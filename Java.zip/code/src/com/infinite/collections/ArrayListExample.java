package com.infinite.collections;

import java.util.*;

public class ArrayListExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList ls = new ArrayList();
		ls.add(34);
		ls.add('S');
		ls.add("sai");
		ls.add(33.45f);
		ls.add('S');
		ls.add("sai");
		ls.add('S');
		for(int a=89;a<=100;a++)
		ls.add(a);
		//System.out.println(ls);
		/*System.out.println(ls.addAll(ls));
		System.out.println("size"+" "+ls.size());
		System.out.println(ls.get(3));
		System.out.println(ls.isEmpty());
		System.out.println(ls.remove(1));
		System.out.println(ls.toArray());*/
		Iterator it = ls.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		/*for(Object p:ls)
		{
			System.out.println(p);*/
		}
		/*for(int i = 0; i<=sizeof(ls);i++)
		{
			if(ls.get(i)==ls)
			{
				ls.remove(i);
			}
		
		}
		System.out.println(ls);*/
		/*for(int i = 0; i<=sizeof(ls);i++)
		{
			if(ls.)
			{
				
			}
		}*/
	
	

	private static int sizeof(ArrayList ls) {
		// TODO Auto-generated method stub
		return 0;
	}

}
