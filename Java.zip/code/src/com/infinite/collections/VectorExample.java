package com.infinite.collections;

import java.util.Vector;
import java.util.Iterator;

public class VectorExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector ls = new Vector();
		ls.add(34);
		ls.add("sai");
		ls.add(33.45f);
		ls.add('S');
		ls.add("sai");
		for (int a = 89; a <= 100; a++)
			ls.add(a);
		System.out.println(ls);
		System.out.println("size" + " " + ls.size());
		System.out.println(ls.get(3));
		System.out.println(ls.isEmpty());
		System.out.println(ls.remove(1));
		System.out.println(ls.toArray());
		Iterator it = ls.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		for (Object p : ls) {
			System.out.println(p);
		}

	}

}
