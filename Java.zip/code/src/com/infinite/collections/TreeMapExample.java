package com.infinite.collections;
import java.util.TreeMap;
public class TreeMapExample {
	public static void main(String [] args)
	{
		TreeMap mp = new TreeMap();
		mp.put(1, "srini");
		mp.put(2, "sai");
		mp.put(3, "kumar");
		System.out.println(mp);
		System.out.println(mp.values());
	}

}
