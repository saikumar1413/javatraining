package com.infinite.servletex;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Voter
 */
public class Voter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Voter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection on = null;

		String firstname1 = request.getParameter("firstname"); //getting values to server from jsp
		String lastname1 = request.getParameter("lasttname");  //getting values to server from jsp
		int age1 = request.getIntHeader("age");  //getting values to server from jsp
		String voterno = request.getParameter("voteridno"); //getting values to server from jsp
		
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver"); //loading driver
			on = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "mysql123@");
			//establishing connection
			Scanner sc = new Scanner(System.in); // scanner class
			PreparedStatement ps = on.prepareStatement("insert into voterlist values(?,?,?,?)");
			//inserting values to database
			ps.setString(1, firstname1);  
			ps.setString(2, lastname1);  
			ps.setInt(3, age1);
			ps.setString(4, voterno);
			int status = ps.executeUpdate(); //to update
			ResultSet rs = ps.executeQuery("select * from voterlist;"); // to store values in resultset
			if(age1>18)
			{
		
				System.out.println("Record insert successfully");
				response.sendRedirect("details.jsp"); // if conditions passes it directs to details.jsp
				}
			else{
				System.out.println("Record failed");
				response.sendRedirect("fail.jsp");
			}
				
			
		} catch(Exception e) {
			System.out.println(e);
		} 
		finally
		{
			try {
				on.close();
			} catch (Exception e) {
				System.out.println(e);
			}
	}

	}
}
