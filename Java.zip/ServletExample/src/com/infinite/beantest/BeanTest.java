package com.infinite.beantest;



import java.util.Date;

import com.infinite.beans.User;

public class BeanTest {
	public static void main(String[] args) {
	User sai = new User();
	sai.setUsername("sai");
	sai.setPassword("ss123");
	sai.setLogindate(new Date());
	sai.display();
	System.out.println(sai.getUsername());
	}

}
