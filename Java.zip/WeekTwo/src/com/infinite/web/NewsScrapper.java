package com.infinite.web;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;


public class NewsScrapper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Document doc = Jsoup.connect("https://www.thehindu.com/").get();
			Elements newsElements = doc.select(".story-card75x1-text");
			System.out.println("<html><head><title>Latest News</title></head></body>");
			System.out.println("<tableborder='1'><tr><th>Headline</th><th>Link</th></th>");
			for(Element element:newsElements) {
				String headline = element.text();
				String link = element.attr("href");
				System.out.println("<tr><td>"+headline+"</td><td><a href = '"+link+"'>Read more</a></td></tr>");
				
			}
			System.out.println("</table></body></html>");
		} catch(IOException e) {
			e.printStackTrace();
		}

	}

}
