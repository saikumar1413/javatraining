package com.infinite.jdbcdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * @author saikumarpu
 *
 */
public class JdbcDbConnection { // class name

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		Connection on = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");// Loading driver
			on = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "mysql123@");
			// establishing connection
			Scanner sc = new Scanner(System.in);
			PreparedStatement ps = on.prepareStatement("insert into company values(?,?,?,?,?)");
			// inserting values
			for (int i = 1; i <= 2; i++) {
				System.out.println("Enter company name ");
				ps.setString(1, sc.next()); // input from user
				System.out.println("Enter address ");
				ps.setString(2, sc.next());
				System.out.println("Enter  country ");
				ps.setString(3, sc.next());
				System.out.println("Enter no of employees ");
				ps.setInt(4, sc.nextInt());
				System.out.println("Enter status ");
				ps.setString(5, sc.next());
				int status = ps.executeUpdate(); // to update
				if (status == 1) // if condition true executes below stmnt
					System.out.println("Record insert successfully");
				else
					System.out.println("Record failed");
				ResultSet rs = ps.executeQuery("select * from company"); // to
																			// execute
																			// querry
																			// and
																			// store
																			// in
																			// resultset
				while (rs.next()) {
					System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3) + " "
							+ rs.getInt(4) + " " + rs.getString(5));
					// printing output
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				on.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

}
