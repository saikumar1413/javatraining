package com.infinite.security;

import org.apache.log4j.Logger;

import org.apache.log4j.PropertyConfigurator;;

public class TestSecurity {
	private static final Logger logger = Logger.getLogger(TestSecurity.class);
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
		final String secretKey = "fwe231";

				String originalString = "root";

				String encryptedString = JavaSecurity.encrypt(originalString, secretKey) ;

				String decryptedString = JavaSecurity.decrypt(encryptedString, secretKey) ;
				
				logger.info(originalString);

				logger.info(encryptedString);

				logger.info(decryptedString);
	}

}
