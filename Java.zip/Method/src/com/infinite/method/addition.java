package com.infinite.method;

public class addition {

	addition() {

	}

	addition(int a, int b) {

	}

	public static int addition1(int a, int b) {
		return a + b;
	}

	public static int add2() {
		int a = 20;
		int b = 30;
		int c = a + b;
		return c;
	}

	void meth1(int i, int j) {
		System.out.println(i + j);
	}

	public static int increment(int a) {
		return ++a;
	}

	public static int decrement(int a) {
		return --a;
	}

	public static void main(String args[]) {
		System.out.println(addition1(20, 20));
		System.out.println(add2());
		new addition().meth1(50, 20);
		System.out.println(increment(20));
		System.out.println(decrement(20));
	}
}