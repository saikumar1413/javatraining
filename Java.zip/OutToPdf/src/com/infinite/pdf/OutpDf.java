package com.infinite.pdf;

 

import java.io.FileNotFoundException;

 

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

 

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

 

public class OutpDf {
	public static String generatePDFFileName(){				// to generate file Name which consists of Date
		Date currentDate = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	try{
		String formattedDate = dateFormat.format(currentDate);
		String nameafterDate = "Infi";
		String pdfFileName = "D:/"+formattedDate + "_"+ nameafterDate + ".pdf";
		return pdfFileName;
		} catch (Exception e){
			System.out.println(e);
			return null;
		}	
	}
	public static char atoz() {
		char a='a';
		while(a<='z') {
			System.out.print(a+" ");
			a++;
		}
		return a;
	}
	public static void main (String args[]){

		Document pdfdoc=new Document();

		try{
			PdfWriter writer =PdfWriter.getInstance(pdfdoc,new FileOutputStream(generatePDFFileName()));
			System.out.println("PDF CREATED");
			pdfdoc.open();
			pdfdoc.add(new Paragraph("Infinite Computer Solutions "));
			pdfdoc.add(new Paragraph("Learning my way"));
			//pdfdoc.add(new Paragraph("A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z"));
			pdfdoc.add(new Paragraph(atoz()));
			pdfdoc.addCreationDate();
			pdfdoc.close();
			writer.close();
		}
		catch (DocumentException e){
			e.printStackTrace();
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}

 

	}
}