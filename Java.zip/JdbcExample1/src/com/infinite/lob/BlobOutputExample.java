package com.infinite.lob;

import java.io.FileOutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BlobOutputExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection on = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver"); // step1: loading the drive
			on = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "mysql123@");
			// establishing connection
			System.out.println("Connection Established");
		
			PreparedStatement ps=on.prepareStatement("select * from imgtable");  
			ResultSet rs=ps.executeQuery();  
			if(rs.next()){//now on 1st row  

			Blob b=rs.getBlob(2);//2 means 2nd column data  
			byte barr[]=b.getBytes(1,(int)b.length());//1 means first image  

			FileOutputStream fout=new FileOutputStream("D:\\Images\\sai.png");  
			fout.write(barr);  
			
			fout.close();
			}
		} catch (Exception e1) {
			System.out.println(e1);
			}
		finally {
			try {
				on.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
}
}
