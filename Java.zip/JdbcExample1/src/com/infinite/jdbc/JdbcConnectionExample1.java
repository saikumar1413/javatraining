package com.infinite.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



/**
 * @author saikumarpu
 *
 */
public class JdbcConnectionExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection on = null;
		try {
			Class.forName("com.mysql.jdbc.Driver"); // step1: loading the drive
			 on = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "mysql123@");
			// establishing connection
			System.out.println("Connection Established");
			Scanner sc = new Scanner(System.in);
			/*Statement stmt = on.createStatement(); // creating statement

			stmt.executeUpdate("insert into employee values('sai ',233,'software')");
			stmt.executeUpdate("delete from employee where department = 'department'");
			stmt.executeUpdate("update employee SET fullname='chowan', department = 'software' WHERE idno = 213 ");*/
			PreparedStatement ps = on.prepareStatement("insert into employee values(?,?,?)");
			System.out.println("enter fullname");
			String s = sc.next();
			if(s.length()==1)
			{
				System.out.println("record sinserted successfully");
				ps.setString(1, s);
			System.out.println("enter idno");
			ps.setInt(2, sc.nextInt());
			System.out.println("enter department");
			ps.setString(3, sc.next());
			int status = ps.executeUpdate();
			if (status == 1)
				System.out.println("Record insert successfully");
			else
				System.out.println("Record failed");
			ResultSet st = ps.executeQuery("select * from employee");

			while (st.next()) {
				System.out.println(st.getString(1) + " " + st.getString(3));
			}
			}
			else
			{
				System.out.println("invalid inpurt");
			}
			/*ResultSet st = stmt.executeQuery("select * from employee");
			while (st.next()) {
				System.out.println(st.getString(1));
				System.out.println(st.getString(3));*/
			
		} catch(Exception e) {
			System.out.println(e);
		} 
		finally
		{
			try {
				on.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}


