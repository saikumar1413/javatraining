package com.infinite.jdbc;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;

import org.apache.log4j.Logger;

import org.apache.log4j.PropertyConfigurator;

//import com.infinite.Jdbc.JavaSec;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

/**
 * @author saikumarpu
 *
 */
public class JdbcConnectionExample {
	private static final Logger logger = Logger.getLogger(JdbcConnectionExample.class);

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Connection on=null;
		PropertyConfigurator.configure("log4j.properties");
		try{
		FileReader fr = new FileReader("mysql.properties");
		Properties pr = new Properties();
			pr.load(fr);

			Class.forName(pr.getProperty("drivername"));
			on = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", JavaSec.decrypt(pr.getProperty("username"), "fwe231"), JavaSec.decrypt(pr.getProperty("password"), "wed235"));
			// establishing connection com.mysql.jdbc.Driver
			logger.info("Connection Established");

			Scanner sc = new Scanner(System.in);
			

			PreparedStatement ps = on.prepareStatement("insert into employee values(?,?,?)");
			logger.info("enter fullname");
			ps.setString(1, sc.next());
			logger.info("enter idno");
			ps.setInt(2, sc.nextInt());
			logger.info("enter department");
			ps.setString(3, sc.next());
			int status = ps.executeUpdate();
			if (status == 1)
				logger.info("Record insert successfully");
			else
				logger.info("Record failed");
			ResultSet st = ps.executeQuery("select * from employee");

			while (st.next()) {
				logger.info(st.getString(1) + " " + st.getString(3));
			}

		} catch (SQLException e1) {
			logger.info(e1);
		} finally {
			try {
				on.close();
			} catch (Exception e) {
				logger.info(e);
			}
		}
	}
}
/*
 * for(int i =0; i<1; i++) { String a = t.next(); String b =
 * t.next(); String c = t.next();
 * 
 * Statement stmt = on.createStatement(); // creating statement
 * stmt.executeUpdate("insert into employee values('"+a+"',"+b+",'"+
 * c+"')");
 * 
 * ResultSet st = stmt.executeQuery("select * from employee");
 * 
 * while (st.next()) {
 * System.out.println(st.getString(1)+" "+st.getString(3)); } }
 */
