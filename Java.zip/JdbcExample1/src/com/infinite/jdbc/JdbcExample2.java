package com.infinite.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.xdevapi.Statement;

public class JdbcExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection on = null;
		try {

			Class.forName("com.mysql.jdbc.Driver"); // step1: loading the drive
			on = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "mysql123@");
			// establishing connection com.mysql.jdbc.Driver
			System.out.println("Connection Established");
			Scanner sc = new Scanner(System.in);
			Statement stmt = (Statement) on.createStatement();
			String firstname = sc.next();
			int idno = sc.nextInt();
			ResultSet st = ((java.sql.Statement) stmt).executeQuery("select * from employee");
			int c = 0;
			if(st.next())
			{
				c=st.getInt(1);
			}
			if(c==0)
				System.out.println("invalid");
			else
				System.out.println("valid");
		}
			catch (SQLException e1) {
				System.out.println(e1);
			} catch (ClassNotFoundException e) {
				System.out.println(e);
			} catch (ClassCastException e2){      
				System.out.println(e2);
				
		} finally {
				try {
					on.close();
				} catch (Exception e) {
					System.out.println(e);
				}
		}
	}

}
