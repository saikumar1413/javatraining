package com.infinite.mvc;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * @author saikumarpu
 *
 */
public class HikariCPTest {  //class name
	private static DataSource datasource = null; //initializing datasource to null

	public static DataSource getDataSource() {
		if (datasource == null) {
			HikariConfig config = new HikariConfig(); //creating config object of HikariConfig
			config.setDriverClassName("com.mysql.cj.jdbc.Driver");  //driver name
			config.setJdbcUrl("jdbc:mysql://localhost:3306/training"); //url
			config.setUsername("root"); //username
			config.setPassword("mysql123@"); //password
			config.setMaximumPoolSize(10);  //max pool size connection pooling
			config.setAutoCommit(true); //setting autocommit true
			config.addDataSourceProperty("cachePrepStmts", "true");
			config.addDataSourceProperty("prepStmtCacheSize", "250");
			config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
			datasource = new HikariDataSource(config);
		}
		return datasource;
	}
}