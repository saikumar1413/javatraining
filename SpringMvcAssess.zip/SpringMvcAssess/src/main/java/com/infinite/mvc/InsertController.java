package com.infinite.mvc;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author saikumarpu
 *
 */
@Controller
public class InsertController { // child controller

	@RequestMapping(value = "/register") // mapping handler to find child
											// controller
	public String insertmedicine(HttpServletRequest request, HttpServletResponse response) {
		Connection con = null; // initalizing connection to null
		String fullname = request.getParameter("fullname");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String birthday = request.getParameter("birthday");
		String gender = request.getParameter("gender");
		String profession = request.getParameter("profession");
		String married = request.getParameter("married");
		//getting values from jsp and assigning to a variable using request.getparameter
		try {
			DataSource datasource = HikariCPTest.getDataSource();
			con = datasource.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into register values(?,?,?,?,?,?,?)");
			ps.setString(1, fullname);
			ps.setString(2, email);
			ps.setString(3, password);
			ps.setString(4, birthday);
			ps.setString(5, gender);
			ps.setString(6, profession);
			ps.setString(7, married);
			// inserting to db using set
			int x = ps.executeUpdate();  // updating
			if (fullname.equals(fullname)) {
				if (x != 0) {
					return "registered";  //returning registered.jsp if login credentials are correct
				} else {
					return "invalid";   //returning invalid.jsp if login credentials are wrong
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return null;
	}
}
