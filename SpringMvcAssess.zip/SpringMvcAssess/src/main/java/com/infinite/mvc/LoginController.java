package com.infinite.mvc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author saikumarpu
 *
 */
@Controller
public class LoginController { // child controller
	@RequestMapping(value="/login",method=RequestMethod.POST)   // mapping handler to find child controller
	public String login(HttpServletRequest request, HttpServletResponse response) {
		Connection con = null; // initalizing connection to null
		String fullname = request.getParameter("fullname");
		String password = request.getParameter("password");
		//getting values from jsp and assigning to a variable using request.getparameter
		
		try {
			DataSource datasource = HikariCPTest.getDataSource();
			con = datasource.getConnection();
			PreparedStatement ps = con.prepareStatement("select fullname,password from register where fullname=?");
			ps.setString(1, fullname);
			// inserting to db using set
			ResultSet rs = ps.executeQuery(); //executing query
			while (rs.next()) {
				if (rs.getString(1).equals(fullname)) {
					if (rs.getString(2).equals(password)) {
						return "welcome"; //returning welcome.jsp if login credentials are correct
					} else {
						return "invalid";  //returning invalid.jsp if login credentials are wrong
					}
				} else {
					return "invalid";  //returning invalid.jsp if login credentials are wrong
				}
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e1) {
			System.out.println(e1);
		}
		return "invalid";
	}
}
