package com.infinite.assessment;

import java.util.Scanner;

class Accountdetails
{
	private String accountId;
	private String accountName;
	private double balance;
	private String loantype;
	
	public Accountdetails(String accountId,String accountName,String loanType)
	{
		this.accountId =accountId;
		this.accountName = accountName;
		this.loantype = loanType;
		this.balance = 0.0;
	}
	
	public Accountdetails() {
		// TODO Auto-generated constructor stub
	}

	public void depositamount(double amount)
	{
		if(amount>0)
		{
			balance += amount;
			System.out.println("Deposite"+amount+"into account"+accountId);
		}
		else
		{
			System.out.println("Invalid deposit");
		}
	}
	
	public void withdrawamount(double amount)
	{
		if(amount>0&&balance>=amount)
		{
			balance-=amount;
			System.out.println("withdrawn"+amount+"from account"+accountId);
		}
		else
		{
			System.out.println("Insufficient balance");
		}
	}
	public void displayAccountdetails()
	{
		System.out.println("Account Id: " + accountId);
		System.out.println("Account Name: " + accountName);
		System.out.println("balance: " + balance);
		System.out.println("Loan Type: " + loantype);
	}
	
}

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Accountdetails obj = new Accountdetails();;
		
		Accountdetails[] accounts = new Accountdetails[10];
		
	
		accounts[0] = new Accountdetails("1234567-ABCD","sai","home");
		accounts[1] = new Accountdetails("1234568-ABCD","Akash","car");
				
	
		accounts[0].displayAccountdetails();
		obj.depositamount(10000);
		obj.withdrawamount(5000);
		obj.displayAccountdetails();
		
		accounts[1].displayAccountdetails();
		obj.depositamount(20000);
		obj.withdrawamount(5000);
		obj.displayAccountdetails();

	}

}
